package dao.generate;

import model.generate.DbCodeGenerateTemplet;

import dao.CommonDao;

public class DbCodeGenerateTempletGenDao extends CommonDao<DbCodeGenerateTemplet>{

}