package dao.generate;

import model.generate.RemoteProject;

import dao.CommonDao;

public class RemoteProjectGenDao extends CommonDao<RemoteProject>{

}