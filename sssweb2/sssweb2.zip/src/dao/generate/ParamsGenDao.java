package dao.generate;

import model.generate.Params;

import dao.CommonDao;

public class ParamsGenDao extends CommonDao<Params>{

}