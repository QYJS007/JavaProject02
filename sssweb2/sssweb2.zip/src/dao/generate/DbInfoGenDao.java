package dao.generate;

import model.generate.DbInfo;

import dao.CommonDao;

public class DbInfoGenDao extends CommonDao<DbInfo>{

}