package dao.generate;

import model.generate.HttpTemplet;

import dao.CommonDao;

public class HttpTempletGenDao extends CommonDao<HttpTemplet>{

}