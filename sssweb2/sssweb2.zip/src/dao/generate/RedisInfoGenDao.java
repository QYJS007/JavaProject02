package dao.generate;

import model.generate.RedisInfo;

import dao.CommonDao;

public class RedisInfoGenDao extends CommonDao<RedisInfo>{

}