package dao.generate;

import model.generate.LocalProject;

import dao.CommonDao;

public class LocalProjectGenDao extends CommonDao<LocalProject>{

}