package dao.generate;

import model.generate.DictionaryDetail;

import dao.CommonDao;

public class DictionaryDetailGenDao extends CommonDao<DictionaryDetail>{

}