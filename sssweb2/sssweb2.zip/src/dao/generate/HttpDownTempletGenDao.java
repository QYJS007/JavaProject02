package dao.generate;

import model.generate.HttpDownTemplet;

import dao.CommonDao;

public class HttpDownTempletGenDao extends CommonDao<HttpDownTemplet>{

}