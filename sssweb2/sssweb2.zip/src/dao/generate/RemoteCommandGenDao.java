package dao.generate;

import model.generate.RemoteCommand;

import dao.CommonDao;

public class RemoteCommandGenDao extends CommonDao<RemoteCommand>{

}