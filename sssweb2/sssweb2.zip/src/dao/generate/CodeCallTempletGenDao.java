package dao.generate;

import model.generate.CodeCallTemplet;

import dao.CommonDao;

public class CodeCallTempletGenDao extends CommonDao<CodeCallTemplet>{

}