package dao.generate;

import model.generate.RemoteCommandGroup;

import dao.CommonDao;

public class RemoteCommandGroupGenDao extends CommonDao<RemoteCommandGroup>{

}