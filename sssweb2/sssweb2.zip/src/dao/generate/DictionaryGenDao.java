package dao.generate;

import model.generate.Dictionary;

import dao.CommonDao;

public class DictionaryGenDao extends CommonDao<Dictionary>{

}