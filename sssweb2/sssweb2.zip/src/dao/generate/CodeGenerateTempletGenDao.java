package dao.generate;

import model.generate.CodeGenerateTemplet;

import dao.CommonDao;

public class CodeGenerateTempletGenDao extends CommonDao<CodeGenerateTemplet>{

}