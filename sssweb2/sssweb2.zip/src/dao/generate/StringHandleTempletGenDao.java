package dao.generate;

import model.generate.StringHandleTemplet;

import dao.CommonDao;

public class StringHandleTempletGenDao extends CommonDao<StringHandleTemplet>{

}