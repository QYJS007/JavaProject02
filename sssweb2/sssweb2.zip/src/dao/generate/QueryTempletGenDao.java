package dao.generate;

import model.generate.QueryTemplet;

import dao.CommonDao;

public class QueryTempletGenDao extends CommonDao<QueryTemplet>{

}