package dao.generate;

import model.generate.LineReplaceTemplet;

import dao.CommonDao;

public class LineReplaceTempletGenDao extends CommonDao<LineReplaceTemplet>{

}